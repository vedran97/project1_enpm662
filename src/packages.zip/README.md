1. This folder contains 3 packages
2. robot_urdf package includes urdf, world, rviz,mesh and launch files for the robot
3. open_loop_controller package has nodes for publishing trajectory and subscribing to it
4. car_teleop package includes teleop node used for robot
5. Each package has a dedicated launch readme which contains details on how to launch them.