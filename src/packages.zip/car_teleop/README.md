# Purpose and usage:

1. This package generates gives access to a keyboard operated teleop controller for robot defined under the robot_urdf package
2. This package has launch file, which executes the teleop node
3. Post building the project, in another terminal call "roslaunch car_teleop teleop.launch"
4. Once you execute the launch file, check the terminal for further instructions on driving the robot.
5. Before launching this node, you have to first spawn the robot in a world, for further instructions pls refer robot_urdf package's readme